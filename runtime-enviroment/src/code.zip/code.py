#!/bin/env python
import time

for i in range(20):
    time.sleep(1)
    print(i)
